from django.db import models


class Item(models.Model):
    # attributes
    item_name = models.CharField(max_length=55)
    description = models.CharField(max_length=55)
    size = models.CharField(max_length=20)
    quantity = models.IntegerField()
    price = models.DecimalField(max_digits=4,decimal_places=2)
    
    vendor = models.ForeignKey('Supplier', related_name="items", on_delete= models.CASCADE)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


#popcorn = Item.objects.create(
#    item_name = 'Butter popcorn',
#    description = 'Butter overload',
#    size = 'XL',
#    quantity = 1,
#    price = 19.99
#)

# all_items = Item.objects.all()

class Supplier(models.Model):

    name = models.CharField(max_length=55)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)