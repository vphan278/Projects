package com.codingdojo.GroupProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroupProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
