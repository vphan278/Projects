# flask-nginx-k8s

This is a CRUD-based Recipe web app built with Python Flask, MySQL, and containerized using Docker. It is reverse-proxied with NGINX and deployed on a Kubernetes cluster (via Minikube).

## Tech Stack

  Backend: Python Flask + Gunicorn
  Frontend: HTML/CSS (Jinja templating)
  Database: MySQL
  Web Server: NGINX (reverse proxy)
  Containerization: Docker
  Orchestration: Kubernetes (Minikube)
  OS: Ubuntu Linux

## Features

  User registration/login (with hashed passwords via Bcrypt)
  Full CRUD operations on recipes
  ESTful Flask routes served by Gunicorn
  MySQL integration via PyMySQL
  Reverse proxy with NGINX
  Multi-container Kubernetes deployment

## SetUp

   minikube start
   eval $(minikube docker-env)

   ![alt text](image-1.png)

## Build Docker Images

   docker build -t flask-app:latest -f flask-app/Dockerfile .
   ![alt text](image-2.png)

   docker build -t nginx-proxy:latest -f nginx/Dockerfile .
   ![alt text](image-4.png)


## Apply Kubernetes Manifests
   kubectl apply -f k8s/

## Create yaml
   deployment.apps/flask-app created
   deployment.apps/nginx created
   service/flask-service created
   service/nginx-service created

## Verify pods are running
   kubectl get pods
   kubectl get svc

   ![alt text](image-5.png)

## Access the App
   minikube service nginx-service
   ![alt text](image-6.png)

## Open Browser

   http://192.168.67.2:30080

   ![alt text](image.png)

## End Browser/project
   kubectl delete -f k8s/