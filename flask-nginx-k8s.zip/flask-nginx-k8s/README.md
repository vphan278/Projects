# Flask App with NGINX and Kubernetes

This project demonstrates how to deploy a simple Flask web application using Docker, NGINX, and Kubernetes.

## Tech Stack

- Python + Flask + Gunicorn
- Docker
- NGINX (as reverse proxy)
- Kubernetes (via YAML manifests)

## Setup

1. Build Docker images:
    ```
    docker build -t flask-app ./flask-app
    docker build -t nginx-proxy ./nginx
    ```

2. Deploy to Kubernetes:
    ```
    kubectl apply -f k8s/
    ```

3. Access the app:
    ```
    minikube service nginx-service
    ```

## Author
Vinh Phan
