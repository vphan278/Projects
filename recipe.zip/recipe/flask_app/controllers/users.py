from flask import render_template, request, redirect, session, flash
# Import app
from flask_app import app
#Import modules from flask
# Import models class
from flask_app.models import user, recipe

from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/register", methods= ["POST"])
def register():
    
    if not user.User.validate_registration(request.form):
        return redirect("/")

    
    data = {
        "first_name": request.form["first_name"],
        "last_name": request.form["last_name"],
        "email": request.form["email"],
        "password": bcrypt.generate_password_hash(request.form["password"]),
    }

    user_id = user.User.create_user(data)
    if user_id:
        session["user_id"] = user_id
    return redirect("/")

@app.route("/recipes")
def dashboard():
    """Welcome Page"""
    if "user_id" not in session:
        flash("Please register or login to continue", "danger")
        return redirect("/")

    current_user = user.User.get_user_by_id({"id": session["user_id"]})
    all_recipes = recipe.Recipe.get_all()
    
    return render_template("recipes.html", user_recipes = all_recipes, current_user = current_user)


@app.route("/login", methods=["POST"])
def login():
    data = {
        "email": request.form["email"]
    }

    print("Login email:", data["email"])  # Add this

    user_in_db = user.User.get_user_by_email(data)

    if not user_in_db:
        flash("Invalid Email or Password", "err_login")
        return redirect("/")

    if not bcrypt.check_password_hash(user_in_db.password, request.form["password"]):
        flash("Invalid Email or Password", "err_login")
        return redirect("/")

    session["user_id"] = user_in_db.id
    return redirect("/recipes")


@app.route("/logout")
def logout():
    session.pop("user_id")
    return redirect("/")


