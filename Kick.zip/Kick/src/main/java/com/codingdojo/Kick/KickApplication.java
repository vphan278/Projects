package com.codingdojo.Kick;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KickApplication {

	public static void main(String[] args) {
		SpringApplication.run(KickApplication.class, args);
	}

}
