from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('register', views.register),
    path('login', views.login),
    path('logout', views.logout),
    path('wish', views.wish),
    path('make', views.make_wish),
    path('make_wish', views.make_wish),
    path('stats', views.stats),
    path('Edit', views.edit),
    path('remove/<int:id>', views.remove_wish, name='remove_wish'),  # <-- ADD THIS
    path('Edit/<int:id>', views.edit_wish, name='edit_wish'),     # For editing a wish
    path('Granted/<int:id>', views.grant_wish, name='grant_wish')  # For granting a wish
]


#path('register', views.register),
#    path('wish', views.wish),
#    path('logout', views.logout),
#    path('login', views.login),
#    path('messages/create', views.messages_create),
#    path('make', views.make_wish),
#    path('Edit', views.Edit),

