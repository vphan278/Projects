from django.shortcuts import render, redirect
from django.contrib import messages
from .models import *
from django.utils import timezone
import bcrypt

def index(request):
    return render(request, 'index.html')

def register(request):
    if request.method == "POST":
        errors = User.objects.register_validator(request.POST)
        if errors:
            for value in errors.values():
                messages.error(request, value)
            return redirect('/')
        hashed_pw = bcrypt.hashpw(request.POST['register_password'].encode(), bcrypt.gensalt()).decode()
        user = User.objects.create(
            first_name=request.POST['register_first_name'],
            last_name=request.POST['register_last_name'],
            email=request.POST['register_email'],
            password=hashed_pw
        )
        request.session['uuid'] = user.id
        return redirect('/wish')
    return redirect('/')

def login(request):
    if request.method == "POST":
        errors = User.objects.login_validator(request.POST)
        if errors:
            for value in errors.values():
                messages.error(request, value)
            return redirect('/')
        user = User.objects.get(email=request.POST['login_email'])
        request.session['uuid'] = user.id
        return redirect('/wish')
    return redirect('/')

def logout(request):
    request.session.flush()
    return redirect('/')

def wish(request):
    if 'uuid' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['uuid'])
    context = {
        'user': user,
        'wishes': Wish.objects.filter(user=user, granted=False),
        'granted_wishes': Wish.objects.filter(granted=True)
    }
    return render(request, 'wish.html', context)

def make_wish(request):
    if 'uuid' not in request.session:
        return redirect('/')
    if request.method == "POST":
        user = User.objects.get(id=request.session['uuid'])
        if len(request.POST['wish_for']) < 1 or len(request.POST['description']) < 1:
            messages.error(request, "Fields cannot be blank")
            return redirect('/make')
        Wish.objects.create(
            item=request.POST['wish_for'],
            description=request.POST['description'],
            user=user
        )
        return redirect('/wish')
    context = {
        'user': User.objects.get(id=request.session['uuid'])
    }
    return render(request, 'make.html', context)

def stats(request):
    if 'uuid' not in request.session:
        return redirect('/')
    context = {
        'user': User.objects.get(id=request.session['uuid'])
    }
    return render(request, 'stats.html', context)

def edit(request):
    if 'uuid' not in request.session:
        return redirect('/')
    context = {
        'user': User.objects.get(id=request.session['uuid'])
    }
    return render(request, 'Edit.html', context)

def remove_wish(request, id):
    if 'uuid' not in request.session:
        return redirect('/')
    try:
        wish = Wish.objects.get(id=id, user_id=request.session['uuid'])
        wish.delete()
    except Wish.DoesNotExist:
        messages.error(request, "Wish not found or not authorized")
    return redirect('/wish')

def edit_wish(request, id):
    if 'uuid' not in request.session:
        return redirect('/')

    try:
        wish = Wish.objects.get(id=id, user_id=request.session['uuid'])
    except Wish.DoesNotExist:
        messages.error(request, "Wish not found or unauthorized")
        return redirect('/wish')

    if request.method == 'POST':
        wish.item = request.POST['wish_for']
        wish.description = request.POST['description']
        wish.save()
        return redirect('/wish')

    context = {
        'wish': wish,
        'user': User.objects.get(id=request.session['uuid'])  # <== make sure this is included
    }
    return render(request, 'edit.html', context)

def grant_wish(request, id):
    if 'uuid' not in request.session:
        return redirect('/')
    try:
        wish = Wish.objects.get(id=id, user_id=request.session['uuid'])
        wish.granted = True
        wish.date_granted = timezone.now()  # You need this field in your model
        wish.save()
    except Wish.DoesNotExist:
        messages.error(request, "Wish not found or not authorized")
    return redirect('/wish')